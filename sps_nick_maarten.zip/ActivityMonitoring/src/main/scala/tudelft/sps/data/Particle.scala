package tudelft.sps.data

case class Particle(
  var x:Int,
  var y:Int,
  var compassError:Double,
  var strideError:Double
)