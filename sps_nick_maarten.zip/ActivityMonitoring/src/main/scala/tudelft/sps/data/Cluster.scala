package tudelft.sps.data

case class Cluster(x: Int, y: Int, covarX: Int, covarY: Int, weight: Double) {
//  def this(covarX: Double, covarY: Double, weight: Double, x: Int, y: Int) =
//    this(x, y, covarX, covarY, weight)
}